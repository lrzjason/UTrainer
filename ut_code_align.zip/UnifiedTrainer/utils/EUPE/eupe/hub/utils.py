# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This software may be used and distributed in accordance with
# the terms of the FAIR Noncommercial Research License.

EUPE_BASE_URL = "https://dl.fbaipublicfiles.com/eupe"
